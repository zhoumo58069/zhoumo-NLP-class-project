from utils.dataset import Dataset
from utils.baseline import Baseline
from utils.scorer import report_score



def execute_demo(language):
    data = Dataset(language)
    
    # for sent in data.trainset:
    #    print(sent['sentence'], sent['target_word'], sent['gold_label'])

    baseline = Baseline(language)
    
    model=baseline.get_word2vec_model(data.trainset, data.testset)
    
    dict_pos_key_value = baseline.get_dic_pos_tag()
    
    dic_freq =  baseline.get_dic_freq(data.trainset, data.testset)

    baseline.train(data.trainset, model, dict_pos_key_value, dic_freq)

    #predictions = baseline.test(data.devset)
    
    predictions_test = baseline.test(data.testset, model, dict_pos_key_value, dic_freq)

    #gold_labels = [sent['gold_label'] for sent in data.devset]
    
    gold_labels_test = [sent['gold_label'] for sent in data.testset]

    #report_score(gold_labels, predictions)
      
    print("{}: {} training - {} dev".format(language, len(data.trainset), len(data.devset)))
    print("{}: {} training - {} test".format(language, len(data.trainset), len(data.testset)))   
    
    report_score(gold_labels_test, predictions_test, detailed=True)
    
    


execute_demo('english')
#execute_demo('spanish')






    
    
    
    
    
    
    
    
    
    