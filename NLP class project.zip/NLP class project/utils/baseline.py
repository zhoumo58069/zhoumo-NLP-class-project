from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
import re
import gensim
import logging
import numpy as np
import nltk
from nltk.corpus import wordnet as wn
from nltk.data import load
from collections import Counter
from sklearn.model_selection import learning_curve
import matplotlib.pyplot as plt

class Baseline(object):

    def __init__(self, language):
        self.language = language
        # from 'Multilingual and Cross-Lingual Complex Word Identification' (Yimam et. al, 2017)
        if language == 'english':
            self.avg_word_length = 5.3
        else:  # spanish
            self.avg_word_length = 6.2
            
        #self.model = svm.SVC()
        self.model = RandomForestClassifier()
        #self.model = LogisticRegression()
        
        
    def get_word2vec_model(self, trainset, testset):  # to get word2vec model
        each_sent=[]
        for sent in trainset:
            each_sent.append(sent['sentence'])
            
        for sent in testset:
            each_sent.append(sent['sentence'])
            
        diff_sent=list(set(each_sent))
        sentences=[]
        
        for sent in diff_sent:
            sentences.append(re.sub("[^\w]"," ",sent).split())           
        
        logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
        model = gensim.models.Word2Vec(sentences, min_count=1, size=10)
        
        return model
    
    def get_dic_freq(self, trainset, testset):  # to get the dict for word frequency
        each_sent=[]
        for sent in trainset:
            each_sent.append(sent['sentence'])
            
        for sent in testset:
            each_sent.append(sent['sentence'])
            
        diff_sent=list(set(each_sent))
        total_word_split=[]
        
        for sent in diff_sent:
            diff_sent_split = re.sub("[^\w]"," ",sent).split()
            total_word_split = total_word_split + diff_sent_split
        
        dic_freq = Counter(total_word_split)
        
        return dic_freq
                
    
    def get_dic_pos_tag(self):  # to get the pos-tag value 
        dict_pos_key = load('help/tagsets/upenn_tagset.pickle')
        dict_pos_key_value = dict.fromkeys(dict_pos_key, 0)   # a dict with all pos-tag types, value=0
        n=0
        for k in list(dict_pos_key_value):            
            dict_pos_key_value[k]=n
            n+=1
        return dict_pos_key_value    # a dict with all pos-tag types, each type has different value
        
               
    def extract_features(self, word, model, dict_pos_key_value, dic_freq):
        len_chars = len(word) / self.avg_word_length
        word_cleaned = re.sub("[^\w]"," ",word).split()
        len_tokens = len(word_cleaned)
        num_synonym = len(wn.synsets(word_cleaned[0]))
        word_tag = nltk.word_tokenize(word_cleaned[0])
        postag = nltk.pos_tag(word_tag)[0][1]
        val_postag = dict_pos_key_value[postag]
        if word_cleaned[0] in model.wv.vocab:                                    
            for i in range(len_tokens):               
                vector_all = 0
                vector_all+= model.wv[word_cleaned[i]]   # deal with phrase
                vector= vector_all/len_tokens               
        else:
            vector=model.wv['and']  # just for several instance, the target word is not in model
                                    # beacause 'didn't' in sents, but 'did' in target word
                                    # '3.5bn' in sents but 'bn' in target word
                                    # 'Shcerf's' in sents but 'Shcerf' in target word
        for j in range(len_tokens):               
            num_freq_all = 0
            num_freq_all+= dic_freq[word_cleaned[j]]   # deal with phrase
            val_freq = num_freq_all/len_tokens     
        
        return np.hstack(([len_chars, len_tokens, num_synonym, val_freq, val_postag], vector))
        #return vector
        #return [len_chars, len_tokens, num_synonym, val_freq, val_postag]

    def train(self, trainset, model, dict_pos_key_value, dic_freq):
        X = []
        y = []
        for sent in trainset:
            X.append(self.extract_features(sent['target_word'], model, dict_pos_key_value, dic_freq))
            y.append(sent['gold_label'])

        self.model.fit(X, y)
        
        plt.figure()
        title = "Learning Curves (system 4)"
        plt.title(title)
        plt.xlabel("Training examples")
        plt.ylabel("Score")
        estimator = self.model
        train_sizes = np.linspace(.1, 1.0,5)
        train_sizes, train_scores,test_scores= learning_curve(estimator, X, y, n_jobs=1, train_sizes=train_sizes)
        train_scores_mean = np.mean(train_scores, axis=1)
        train_scores_std = np.std(train_scores, axis=1)
        # test_scores_mean = np.mean(test_scores, axis=1)
        # test_scores_std = np.std(test_scores, axis=1)
        plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                         train_scores_mean + train_scores_std, alpha=0.1,
                         color="r")
        plt.plot(train_sizes, train_scores_mean, 'o-', color="r",
                 label="Training score")

        plt.show()

    def test(self, testset, model, dict_pos_key_value, dic_freq):
        X = []        
        for sent in testset:
            X.append(self.extract_features(sent['target_word'], model, dict_pos_key_value, dic_freq))
            
        return self.model.predict(X)
